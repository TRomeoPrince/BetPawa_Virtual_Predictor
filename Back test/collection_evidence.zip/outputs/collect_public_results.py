"""Public-only betPawa snapshot collector; no cookies, login, or ID guessing."""
import requests,json,pathlib,datetime,hashlib,time,concurrent.futures
ROOT=pathlib.Path('work/collection');ROOT.mkdir(exist_ok=True)
BASE='https://www.betpawa.ug'
HEADERS={'X-Pawa-Brand':'betpawa-uganda','X-Pawa-Language':'en','Devicetype':'desktop','Accept':'application/json','User-Agent':'PublicResultsResearch/1.0'}
def get(task):
 name,url=task;p=ROOT/(name+'.json');meta=ROOT/(name+'.meta.json')
 if p.exists() and meta.exists():return json.loads(meta.read_text())
 rec={'url':url,'retrieved_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'raw_file':p.name}
 try:
  r=requests.get(url,headers=HEADERS,timeout=25);p.write_bytes(r.content)
  rec.update(http_status=r.status_code,sha256=hashlib.sha256(r.content).hexdigest(),content_type=r.headers.get('Content-Type'),bytes=len(r.content),server_date=r.headers.get('Date'))
 except requests.RequestException as e:rec['error']=str(e)
 meta.write_text(json.dumps(rec,indent=2));time.sleep(.15)
 return rec
if __name__=='__main__':
 for kind in ['past','actual']:get(('seasons_'+kind,BASE+'/api/sportsbook/virtual/v2/seasons/list/'+kind))
 past=json.loads((ROOT/'seasons_past.json').read_text())['seasons']
 tasks=[]
 for s in past:
  tasks.append(('standings_'+s['id'],BASE+'/api/sportsbook/virtual/v2/standings/by-season/'+s['id']))
  for rnd in s['rounds']:
   tasks.append(('round_'+rnd['id'],BASE+'/api/sportsbook/virtual/v3/events/list/by-round/'+rnd['id']+'?page=matchups'))
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:
  for i,r in enumerate(ex.map(get,tasks)):
   if i%30==0:print('Downloaded',i+1,'/',len(tasks),'status',r.get('http_status'),flush=True)
 print('Finished',len(tasks),flush=True)
