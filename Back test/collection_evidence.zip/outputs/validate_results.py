"""Validate captured public responses. Archive deduplication is mandatory for the new-only export."""
import csv,json,pathlib,collections,hashlib,argparse,datetime
P=pathlib.Path('work/collection');O=pathlib.Path('outputs')
FIELDS=['league_id','league','season_id','season_name','matchday','round_id','fixture_id','fixture','home_id','home_team','away_id','away_team','ht_home','ht_away','ft_home','ft_away','kickoff_utc','season_end_utc','source_url','retrieved_at_utc','response_sha256','settlement_provenance','explicit_settlement_status','standings_source_url','standings_response_sha256','archive_comparison_status']
def write_csv(path,fields,rows):
 with path.open('w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
def run(archive=None):
 seasons=json.loads((P/'seasons_past.json').read_text())['seasons'];coverage=[];accepted=[];quarantine=[]
 all_seen=set()
 for s in seasons:
  sid=s['id'];sp=P/f'standings_{sid}.json';stand=json.loads(sp.read_text());sm=json.loads((P/f'standings_{sid}.meta.json').read_text())
  groups=collections.defaultdict(list);errors=collections.defaultdict(list)
  for rnd in s['rounds']:
   rid=rnd['id'];p=P/f'round_{rid}.json';meta=json.loads((P/f'round_{rid}.meta.json').read_text())
   if meta.get('http_status')!=200:continue
   for e in json.loads(p.read_text()).get('responses',[]):
    lid=e['competition']['id'];eid=e['id'];key=(sid,lid,eid)
    try:
     if key in all_seen:raise ValueError('duplicate fixture ID')
     all_seen.add(key)
     parts={str(p['id']):p for p in e['participants']}
     scores={}
     for pr in e['results']['participantPeriodResults']:
      side=pr['participant']['type'];pid=pr['participant']['id'];scores[side]={'id':pid,'name':parts[pid]['name']}
      for v in pr['periodResults']:
       if v['type']=='SCORE':scores[side][v['period']['slug']]=int(v['result'])
     h,a=scores['HOME'],scores['AWAY'];ht=[h['FIRST_HALF'],a['FIRST_HALF']];ft=[h['FULL_TIME_EXCLUDING_OVERTIME'],a['FULL_TIME_EXCLUDING_OVERTIME']]
     for side in [h,a]:
      if side['FIRST_HALF']+side['SECOND_HALF']!=side['FULL_TIME_EXCLUDING_OVERTIME']:raise ValueError('period score mismatch')
     if any(v<0 for v in ht+ft):raise ValueError('negative score')
     if e['additionalInfo']['live']:raise ValueError('live event')
     end=datetime.datetime.fromisoformat(s['tradingTime']['end'].replace('Z','+00:00'))
     got=datetime.datetime.fromisoformat(meta['retrieved_at_utc'])
     kickoff=datetime.datetime.fromisoformat(e['startTime'].replace('Z','+00:00'))
     if end>=got or kickoff>=got:raise ValueError('not yet completed in time')
     groups[lid].append(dict(zip(FIELDS,[lid,e['competition']['name'],sid,s['name'],int(rnd['name']),rid,eid,e['name'],h['id'],h['name'],a['id'],a['name'],*ht,*ft,e['startTime'],s['tradingTime']['end'],meta['url'],meta['retrieved_at_utc'],meta['sha256'],'past-season index + elapsed season + non-live + HT/second-half/FT consistency + all-team final standings reconciliation','not exposed',sm['url'],sm['sha256'],'not compared: original Library CSV unavailable'])))
    except (KeyError,ValueError,TypeError) as exc:errors[lid].append(f'{eid}: {exc}')
  for comp in stand.get('competitionStandings',[]):
   lid=comp['id'];rows=groups[lid];issues=errors[lid];teams=comp['participantStandings'];ids={t['id'] for t in teams};rounds={r['round_id'] for r in rows}
   if rounds!={r['id'] for r in s['rounds']}:issues.append('missing advertised round(s)')
   stats=collections.defaultdict(lambda:collections.Counter())
   for rnd in s['rounds']:
    rr=[r for r in rows if r['round_id']==rnd['id']];used=[r[k] for r in rr for k in ['home_id','away_id']]
    if len(used)!=len(ids) or set(used)!=ids:issues.append('round '+rnd['name']+' missing/duplicate teams')
   for r in rows:
    for own,opp,gf,ga in [(r['home_id'],r['away_id'],r['ft_home'],r['ft_away']),(r['away_id'],r['home_id'],r['ft_away'],r['ft_home'])]:
     z=stats[own];z['played']+=1;z['gf']+=gf;z['ga']+=ga;z['won' if gf>ga else 'draw' if gf==ga else 'lost']+=1
   for t in teams:
    z=stats[t['id']];p=t['points'];sc=t['scoreStanding']
    if any(z[k]!=p[k] for k in ['won','draw','lost']) or z['gf']!=sc['scored'] or z['ga']!=sc['conceded'] or 3*z['won']+z['draw']!=p['total']:issues.append('standings mismatch '+t['id'])
    if z['played']!=len(s['rounds']):issues.append('incomplete team '+t['id'])
   ok=not issues
   coverage.append({'league_id':lid,'league':comp['name'],'season_id':sid,'advertised_matchdays':len(s['rounds']),'collected_matchdays':len(rounds),'teams':len(ids),'fixtures':len(rows),'season_end_utc':s['tradingTime']['end'],'verification':'PASS' if ok else 'QUARANTINE','issues':'; '.join(issues)})
   (accepted if ok else quarantine).extend(rows)
 # No result may be called new without an archive comparison.
 new=[]
 if archive:
  with open(archive,newline='',encoding='utf-8-sig') as f:
   reader=csv.DictReader(f);columns=set(reader.fieldnames or []);old=list(reader)
  required={'league_id','season_id','round_id','home_id','away_id','fixture_id'}
  if not old or not required.issubset(columns):raise ValueError('Map archive columns to canonical IDs before deduplicating; no guessed identity matching allowed')
  old_by_id={r['fixture_id']:r for r in old}
  for r in accepted:
   previous=old_by_id.get(r['fixture_id'])
   if previous and any(str(previous[c])!=str(r[c]) for c in ['ht_home','ht_away','ft_home','ft_away'] if c in previous):raise ValueError('Conflicting archive scores for fixture '+r['fixture_id'])
  keys={(r['league_id'],r['season_id'],r['round_id'],r['home_id'],r['away_id']) for r in old};event_ids={r['fixture_id'] for r in old}
  for r in accepted:
   k=tuple(str(r[c]) for c in ['league_id','season_id','round_id','home_id','away_id'])
   r['archive_comparison_status']='duplicate' if k in keys or r['fixture_id'] in event_ids else 'new'
   if r['archive_comparison_status']=='new':new.append(r)
  # A new-only complete-season export cannot contain fragments of an overlapping season.
  by_season=collections.defaultdict(list)
  for r in accepted:by_season[(r['league_id'],r['season_id'])].append(r)
  new=[r for group in by_season.values() if all(x['archive_comparison_status']=='new' for x in group) for r in group]
 write_csv(O/'verified_complete_seasons_pending_archive_comparison.csv',FIELDS,accepted)
 write_csv(O/'verified_new_seasons.csv',FIELDS,new)
 write_csv(O/'quarantined_fixtures.csv',FIELDS,quarantine)
 write_csv(O/'season_coverage.csv',list(coverage[0]),coverage)
 summary={'provider_seasons':len(seasons),'league_seasons_pass':sum(r['verification']=='PASS' for r in coverage),'league_seasons_quarantined':sum(r['verification']!='PASS' for r in coverage),'verified_fixtures_pending_archive_comparison':len(accepted),'new_only_fixtures':len(new),'quarantined_fixtures':len(quarantine),'archive_available':bool(archive)}
 (O/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--archive');run(a.parse_args().archive)
